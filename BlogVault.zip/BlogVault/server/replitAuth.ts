import session from "express-session";
import type { Express, RequestHandler } from "express";
import connectPg from "connect-pg-simple";
import { storage } from "./storage";
import crypto from "crypto";

const ADMIN_EMAIL = "adaenonche92@gmail.com";
const ADMIN_PASSWORD = "Michael123$$$";

// Hash password using simple crypto approach
function hashPassword(password: string): string {
  return crypto
    .createHash("sha256")
    .update(password + "insighthub-salt")
    .digest("hex");
}

// Verify password
function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: sessionTtl,
    },
  });
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());

  // Ensure admin user exists in database on startup
  await ensureAdminExists();

  app.post("/api/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res
          .status(400)
          .json({ message: "Email and password are required" });
      }

      if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
        return res
          .status(401)
          .json({ message: "Invalid email or password" });
      }

      // Get user from database
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Store user in session
      (req as any).session.userId = user.id;
      (req as any).session.userEmail = user.email;

      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ message: "Login failed" });
        }
        res.json({ success: true });
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.get("/api/logout", (req: any, res) => {
    // Clear session data
    req.session.userId = null;
    req.session.userEmail = null;
    
    req.session.destroy((err: any) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.redirect("/login");
    });
  });
}

// Ensure admin user exists in the database
async function ensureAdminExists() {
  try {
    const existingAdmin = await storage.getUserByEmail(ADMIN_EMAIL);
    if (!existingAdmin) {
      await storage.upsertUser({
        email: ADMIN_EMAIL,
        firstName: "Admin",
        lastName: "User",
        profileImageUrl: null,
        passwordHash: hashPassword(ADMIN_PASSWORD),
      });
    }
  } catch (error) {
    console.error("Error ensuring admin exists:", error);
  }
}

export const isAuthenticated: RequestHandler = (req: any, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  // Attach user to req for downstream handlers
  req.user = {
    id: req.session.userId,
    email: req.session.userEmail,
  };
  return next();
};

// Admin-only middleware
export const isAdmin: RequestHandler = (req: any, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  if (req.session.userEmail !== ADMIN_EMAIL) {
    return res.status(403).json({ message: "Forbidden: Admin access only" });
  }

  // Attach user to req for downstream handlers
  req.user = {
    id: req.session.userId,
    email: req.session.userEmail,
  };

  return next();
};
