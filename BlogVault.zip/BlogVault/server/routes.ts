import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isAdmin } from "./replitAuth";
import { insertPostSchema, updatePostSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Public routes - Posts
  app.get("/api/posts", async (req, res) => {
    try {
      const posts = await storage.getPublishedPosts();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.get("/api/posts/:id", async (req, res) => {
    try {
      const post = await storage.getPostWithAuthor(req.params.id);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  // Public route - Admin profile (for About page)
  app.get("/api/admin/profile", async (req, res) => {
    try {
      const adminData = await storage.getFirstAdmin();
      if (!adminData) {
        return res.json({ user: null, profile: null });
      }
      res.json(adminData);
    } catch (error) {
      console.error("Error fetching admin profile:", error);
      res.status(500).json({ message: "Failed to fetch admin profile" });
    }
  });

  // Helper function to get authenticated user
  function getAuthenticatedUser(req: any) {
    return req.user;
  }

  // Protected Admin routes
  app.get("/api/admin/posts", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const user = getAuthenticatedUser(req);
      const posts = await storage.getPostsByAuthor(user.id);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching admin posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.post("/api/posts", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const user = getAuthenticatedUser(req);
      
      const validatedData = insertPostSchema.parse({
        ...req.body,
        authorId: user.id,
      });

      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      console.error("Error creating post:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.patch("/api/posts/:id", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const user = getAuthenticatedUser(req);
      const postId = req.params.id;
      
      // Verify the post belongs to the admin
      const existingPost = await storage.getPostById(postId);
      if (!existingPost) {
        return res.status(404).json({ message: "Post not found" });
      }
      if (existingPost.authorId !== user.id) {
        return res.status(403).json({ message: "Forbidden: You can only edit your own posts" });
      }

      const validatedData = updatePostSchema.parse(req.body);
      const post = await storage.updatePost(postId, validatedData);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.json(post);
    } catch (error) {
      console.error("Error updating post:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update post" });
    }
  });

  app.delete("/api/posts/:id", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const user = getAuthenticatedUser(req);
      const postId = req.params.id;
      
      // Verify the post belongs to the admin
      const existingPost = await storage.getPostById(postId);
      if (!existingPost) {
        return res.status(404).json({ message: "Post not found" });
      }
      if (existingPost.authorId !== user.id) {
        return res.status(403).json({ message: "Forbidden: You can only delete your own posts" });
      }

      const deleted = await storage.deletePost(postId);
      if (!deleted) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  // Admin profile update
  app.put("/api/admin/profile", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const user = getAuthenticatedUser(req);
      
      const { tagline, bio, galleryImages, socialLinks } = req.body;
      
      const profile = await storage.upsertAdminProfile({
        userId: user.id,
        tagline,
        bio,
        galleryImages,
        socialLinks,
      });
      
      res.json(profile);
    } catch (error) {
      console.error("Error updating admin profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
