import {
  users,
  posts,
  adminProfile,
  type User,
  type UpsertUser,
  type Post,
  type InsertPost,
  type UpdatePost,
  type AdminProfile,
  type InsertAdminProfile,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Post operations
  getAllPosts(): Promise<Post[]>;
  getPublishedPosts(): Promise<Post[]>;
  getPostById(id: string): Promise<Post | undefined>;
  getPostWithAuthor(id: string): Promise<(Post & { author: User }) | undefined>;
  getPostsByAuthor(authorId: string): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, post: UpdatePost): Promise<Post | undefined>;
  deletePost(id: string): Promise<boolean>;
  
  // Admin profile operations
  getAdminProfile(userId: string): Promise<AdminProfile | undefined>;
  upsertAdminProfile(profile: InsertAdminProfile): Promise<AdminProfile>;
  getFirstAdmin(): Promise<{ user: User; profile: AdminProfile | null } | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // First try to find existing user by email (for cases where OIDC sub changes between sessions)
    if (userData.email) {
      const [existingByEmail] = await db
        .select()
        .from(users)
        .where(eq(users.email, userData.email));
      
      if (existingByEmail) {
        // Update existing user found by email (keep original id for foreign key consistency)
        const [updated] = await db
          .update(users)
          .set({
            firstName: userData.firstName,
            lastName: userData.lastName,
            profileImageUrl: userData.profileImageUrl,
            updatedAt: new Date(),
          })
          .where(eq(users.email, userData.email))
          .returning();
        return updated;
      }
    }
    
    // No existing user, try insert with upsert on id
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  // Post operations
  async getAllPosts(): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .orderBy(desc(posts.createdAt));
  }

  async getPublishedPosts(): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.published, true))
      .orderBy(desc(posts.createdAt));
  }

  async getPostById(id: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post;
  }

  async getPostWithAuthor(id: string): Promise<(Post & { author: User }) | undefined> {
    const result = await db
      .select()
      .from(posts)
      .leftJoin(users, eq(posts.authorId, users.id))
      .where(eq(posts.id, id));
    
    if (!result[0]) return undefined;
    
    const { posts: post, users: author } = result[0];
    if (!author) return undefined;
    
    return { ...post, author };
  }

  async getPostsByAuthor(authorId: string): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.authorId, authorId))
      .orderBy(desc(posts.createdAt));
  }

  async createPost(postData: InsertPost): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values(postData)
      .returning();
    return post;
  }

  async updatePost(id: string, postData: UpdatePost): Promise<Post | undefined> {
    const [post] = await db
      .update(posts)
      .set({ ...postData, updatedAt: new Date() })
      .where(eq(posts.id, id))
      .returning();
    return post;
  }

  async deletePost(id: string): Promise<boolean> {
    const result = await db
      .delete(posts)
      .where(eq(posts.id, id))
      .returning();
    return result.length > 0;
  }

  // Admin profile operations
  async getAdminProfile(userId: string): Promise<AdminProfile | undefined> {
    const [profile] = await db
      .select()
      .from(adminProfile)
      .where(eq(adminProfile.userId, userId));
    return profile;
  }

  async upsertAdminProfile(profileData: InsertAdminProfile): Promise<AdminProfile> {
    const [profile] = await db
      .insert(adminProfile)
      .values(profileData)
      .onConflictDoUpdate({
        target: adminProfile.userId,
        set: {
          ...profileData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return profile;
  }

  async getFirstAdmin(): Promise<{ user: User; profile: AdminProfile | null } | undefined> {
    // Get the admin user by email
    const ADMIN_EMAIL = "adaenonche92@gmail.com";
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, ADMIN_EMAIL));
    
    if (!user) {
      // Fallback: get first user with posts
      const [anyUser] = await db.select().from(users).limit(1);
      if (!anyUser) return undefined;
      
      const profile = await this.getAdminProfile(anyUser.id);
      return { user: anyUser, profile: profile || null };
    }
    
    const profile = await this.getAdminProfile(user.id);
    return { user, profile: profile || null };
  }
}

export const storage = new DatabaseStorage();
