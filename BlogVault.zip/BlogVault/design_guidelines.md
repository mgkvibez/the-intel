# Design Guidelines: Corporate Blog Platform

## Design Approach
**Selected Approach:** Hybrid - Drawing from Medium's content-focused clarity + Ghost's professional publishing aesthetic + Notion's clean admin interface

**Core Principles:**
- Corporate professionalism with approachable warmth
- Content-first hierarchy prioritizing readability
- Efficient admin workflows with clear visual feedback
- Trust and credibility through clean, spacious layouts

## Typography System

**Font Stack:**
- Primary: Inter (via Google Fonts) - headings, UI elements
- Secondary: Merriweather - long-form article content

**Type Scale:**
- Hero headlines: text-5xl to text-6xl, font-bold
- Page titles: text-4xl, font-semibold
- Article titles (cards): text-2xl, font-semibold
- Section headers: text-xl, font-semibold
- Body text: text-base (articles) / text-sm (UI)
- Metadata/labels: text-sm, font-medium

## Layout System

**Spacing Primitives:** Tailwind units of 4, 6, 8, 12, 16, 24
- Component padding: p-6, p-8
- Section spacing: py-16, py-24
- Card gaps: gap-8, gap-12
- Inline spacing: space-x-4, space-y-6

**Grid Structures:**
- Main blog grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Admin dashboard: Single column max-w-4xl for focused editing
- About page: Two-column layout (bio + image gallery)

**Container Widths:**
- Blog grid container: max-w-7xl
- Article reading: max-w-3xl (optimal reading width ~65-75 characters)
- Admin forms: max-w-2xl

## Component Library

### Navigation Bar
- Sticky header with subtle shadow on scroll
- Logo left, navigation links center, admin login/profile right
- Height: h-16 with py-4
- Links: "Home" | "About Admin" | "Admin Login/Dashboard"

### Blog Post Cards (Main Page)
- Rounded corners: rounded-xl
- Card padding: p-6
- Subtle elevation with border
- Content type badge (Article/Video/Audio) - top-left, rounded-full px-3 py-1
- Thumbnail/featured image: aspect-video, rounded-lg mb-4
- Title: text-2xl font-semibold mb-3
- Excerpt: text-sm line-clamp-3 mb-4
- Metadata row: flex justify-between items-center (date, read time, category tag)
- Hover: Subtle transform scale-[1.02] transition

### About Admin Page
- Hero section with admin photo: rounded-full w-48 h-48 with border-4
- Bio section: max-w-3xl prose prose-lg
- Photo gallery: Masonry grid (3 columns desktop, 2 tablet, 1 mobile)
- Gallery images: rounded-lg with hover overlay effect

### Admin Authentication Page
- Centered card layout: max-w-md mx-auto
- Card: rounded-2xl with p-8
- Google sign-in button: w-full, h-12, flex items-center justify-center gap-3
- Security note below: text-xs with lock icon

### Admin Dashboard
- Sidebar navigation (mobile: drawer)
- Main content area: max-w-4xl
- Action buttons: Primary (Create Post), Secondary (View Published)
- Posts table: w-full with alternating row backgrounds
- Table columns: Title | Type | Date | Actions (Edit/Delete icons)
- Edit/Delete icons: w-5 h-5 with hover color change

### Post Creation/Edit Form
- Rich text editor: min-h-96 with toolbar
- Content type selector: Radio buttons with icons (Article/Video/Audio)
- Title input: text-2xl font-semibold, border-b-2
- Video URL input (if video selected): w-full h-12
- Audio upload zone (if audio selected): Drag-drop area with dashed border
- Publish button: Fixed bottom bar with w-full md:w-auto

### Article Display (Individual Post)
- Hero image: Full-width, max-h-96, object-cover
- Title overlay on hero (if hero image exists): Gradient overlay with text-5xl white text
- Article metadata: flex row with avatar, author name, date, read time
- Content: prose prose-lg max-w-3xl with generous line-height (leading-relaxed)
- Video embed: aspect-video rounded-lg my-8
- Audio player: Custom styled with controls, w-full rounded-lg

### Footer
- Three-column layout desktop (About | Quick Links | Contact)
- Social links with icons
- Copyright notice: text-sm
- Background: Subtle contrast from body

## Animations
**Minimal & Purposeful:**
- Card hover: transform scale-[1.02] transition-transform duration-200
- Navigation links: Underline slide-in on hover
- Button states: Standard opacity/scale feedback
- Page transitions: Fade-in content (opacity-0 to opacity-100)

## Images

### Hero Image
**Main Page Hero:** Full-width banner (h-64 md:h-96) featuring abstract corporate imagery or tech/health/finance composite. Professional stock photo showing modern workspace or abstract data visualization. Image should have gradient overlay (from-black/50 to-transparent) for text legibility.

### About Admin Page
- **Profile Photo:** Professional headshot, circular crop
- **Gallery Images (4-6):** Mix of professional photos, speaking engagements, workspace shots - all rounded-lg with consistent aspect ratio

### Blog Post Thumbnails
- **Placeholder Strategy:** Each post card includes featured image (aspect-video)
- Images should relate to post category (health: wellness imagery, finance: charts/growth, tech: devices/code)
- Consistent treatment: rounded-lg with object-cover

### Admin Dashboard
- Empty state illustrations when no posts exist
- No heavy imagery - icon-focused for efficiency

## Accessibility Standards
- Consistent focus states: ring-2 ring-offset-2 on all interactive elements
- Form labels: font-medium mb-2 for all inputs
- Semantic HTML throughout
- ARIA labels for icon-only buttons
- Keyboard navigation support for all admin functions