# InsightHub - Corporate Blog Platform

## Overview

InsightHub is a corporate blog platform focused on delivering expert content across three verticals: Health, Finance, and Technology. The platform supports multiple content types (articles, videos, audio) and provides a clean, professional publishing experience with both public-facing blog pages and an authenticated admin dashboard for content management.

The application is built as a full-stack TypeScript monorepo using a modern React frontend with Express backend, designed for deployment on Replit with integrated authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack React Query for server state management and caching

**UI Component System**
- shadcn/ui component library (New York style variant) with Radix UI primitives
- Tailwind CSS for utility-first styling with custom design tokens
- CVA (Class Variance Authority) for component variant management
- Dark/light theme support via context-based theme provider

**Design System**
- Typography: Inter for UI elements, Merriweather for article content
- Three-column responsive grid for blog posts (mobile → tablet → desktop)
- Category-based color coding: green (Health), blue (Finance), purple (Tech)
- Content type icons: FileText (articles), Video (videos), Headphones (audio)

**State Management Strategy**
- React Query handles all server state with aggressive caching (staleTime: Infinity)
- Local component state for UI interactions (theme, mobile menu, filters)
- Custom hooks pattern: `useAuth()` for authentication state
- Query invalidation on mutations for optimistic updates

### Backend Architecture

**Server Framework**
- Express.js with TypeScript
- Session-based authentication using express-session
- PostgreSQL sessions stored in database via connect-pg-simple
- Request logging middleware with timestamp and duration tracking

**Authentication System**
- Email/password authentication for single admin user
- Admin credentials: email `adaenonche92@gmail.com`, password `Michael123$$$`
- Session-based authentication using express-session with PostgreSQL session store
- Session TTL: 7-day cookie lifetime
- Protected routes via `isAuthenticated` and `isAdmin` middleware
- Login form at `/login` page with validation
- Admin restriction: Only the specific email/password combination has admin access
- Only authenticated admin users can create, edit, and delete posts

**API Design Pattern**
- RESTful endpoints with conventional HTTP methods
- Public routes: GET /api/posts, GET /api/posts/:id, GET /api/admin/profile
- Protected routes: All POST/PUT/DELETE operations require authentication
- JSON request/response bodies with Zod validation
- Consistent error handling with status codes and messages

**Database Layer**
- Drizzle ORM with type-safe schema definitions
- Neon serverless PostgreSQL via WebSocket connection (@neondatabase/serverless)
- Repository pattern: `DatabaseStorage` class implements `IStorage` interface
- Connection pooling with pg Pool

### Data Storage Architecture

**Database Schema**
1. `sessions` table - Required for Replit Auth, stores Express session data
2. `users` table - User profiles with email, names, profile image
3. `posts` table - Blog posts with title, content, category, contentType, media URLs
4. `adminProfile` table - Extended admin user metadata (bio, tagline, social links, gallery)

**Key Relationships**
- Posts reference users via `authorId` foreign key
- AdminProfile references users via `userId` (one-to-one)
- Soft deletion pattern: `published` boolean flag for post visibility

**Data Validation**
- Drizzle-zod integration generates Zod schemas from Drizzle tables
- Separate insert/update schemas for different validation rules
- Form validation on client matches server-side schema validation

### External Dependencies

**Authentication & Session Management**
- Replit Auth (OpenID Connect) - SSO authentication for Replit users
- Passport.js - Authentication middleware strategy pattern
- connect-pg-simple - PostgreSQL session store adapter
- express-session - Server-side session management

**Database & ORM**
- Neon Database - Serverless PostgreSQL hosting
- Drizzle ORM - Type-safe database queries and migrations
- @neondatabase/serverless - WebSocket-based Postgres client
- ws - WebSocket library for Neon connection

**UI Component Libraries**
- Radix UI - Unstyled accessible component primitives (20+ components)
- shadcn/ui - Pre-styled component collection built on Radix
- Tailwind CSS - Utility-first CSS framework
- Lucide React - Icon library

**Form & Validation**
- React Hook Form - Form state management with minimal re-renders
- Zod - TypeScript-first schema validation
- @hookform/resolvers - Integrates Zod with React Hook Form

**Utilities & Tooling**
- date-fns - Date formatting and manipulation
- clsx + tailwind-merge - Conditional className composition
- nanoid - Unique ID generation
- memoizee - Function memoization for OIDC config caching

**Development Tools**
- Vite plugins: @replit/vite-plugin-runtime-error-modal, cartographer, dev-banner
- TypeScript - Static type checking across codebase
- ESBuild - Server bundling with selective dependency bundling

**Build Strategy**
- Client built with Vite to `dist/public`
- Server bundled with ESBuild to `dist/index.cjs`
- Allowlist-based dependency bundling reduces cold start syscalls
- Static file serving from dist/public in production