import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PostCard } from "@/components/post-card";
import { PostCardSkeleton } from "@/components/loading-skeleton";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, TrendingUp, Cpu, Grid3X3, Sparkles } from "lucide-react";
import type { Post } from "@shared/schema";

type CategoryFilter = "all" | "health" | "finance" | "tech";
type ContentTypeFilter = "all" | "article" | "video" | "audio";

const categoryIcons = {
  health: Heart,
  finance: TrendingUp,
  tech: Cpu,
};

export default function Home() {
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");
  const [contentTypeFilter, setContentTypeFilter] = useState<ContentTypeFilter>("all");

  const { data: posts, isLoading, error } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
    staleTime: 0,
  });

  const filteredPosts = posts?.filter((post) => {
    if (categoryFilter !== "all" && post.category.toLowerCase() !== categoryFilter) {
      return false;
    }
    if (contentTypeFilter !== "all" && post.contentType !== contentTypeFilter) {
      return false;
    }
    return post.published;
  });

  const categories: { value: CategoryFilter; label: string }[] = [
    { value: "all", label: "All Topics" },
    { value: "health", label: "Health" },
    { value: "finance", label: "Finance" },
    { value: "tech", label: "Tech" },
  ];

  const contentTypes: { value: ContentTypeFilter; label: string }[] = [
    { value: "all", label: "All Types" },
    { value: "article", label: "Articles" },
    { value: "video", label: "Videos" },
    { value: "audio", label: "Audio" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-primary/5 via-background to-background py-16 md:py-24">
        <div className="container mx-auto max-w-7xl px-6">
          <div className="text-center space-y-6">
            <Badge variant="secondary" className="px-4 py-2">
              <Sparkles className="h-3.5 w-3.5 mr-2" />
              Welcome Back
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
              Latest Insights
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our latest articles, videos, and audio content on health, finance, and technology.
            </p>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="border-b sticky top-16 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto max-w-7xl px-6 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <Tabs value={categoryFilter} onValueChange={(v) => setCategoryFilter(v as CategoryFilter)}>
              <TabsList className="bg-muted/50">
                {categories.map((cat) => {
                  const Icon = cat.value !== "all" ? categoryIcons[cat.value as keyof typeof categoryIcons] : Grid3X3;
                  return (
                    <TabsTrigger 
                      key={cat.value} 
                      value={cat.value}
                      data-testid={`filter-category-${cat.value}`}
                      className="gap-2"
                    >
                      <Icon className="h-4 w-4" />
                      <span className="hidden sm:inline">{cat.label}</span>
                    </TabsTrigger>
                  );
                })}
              </TabsList>
            </Tabs>

            <div className="flex gap-2 flex-wrap">
              {contentTypes.map((type) => (
                <Button
                  key={type.value}
                  variant={contentTypeFilter === type.value ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setContentTypeFilter(type.value)}
                  data-testid={`filter-type-${type.value}`}
                >
                  {type.label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Content Grid */}
      <section className="py-12">
        <div className="container mx-auto max-w-7xl px-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <PostCardSkeleton key={i} />
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-16">
              <p className="text-destructive">Failed to load posts. Please try again later.</p>
            </div>
          ) : filteredPosts && filteredPosts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <EmptyState
              title="No posts found"
              description={
                categoryFilter !== "all" || contentTypeFilter !== "all"
                  ? "Try adjusting your filters to see more content."
                  : "Check back soon for new content!"
              }
            />
          )}
        </div>
      </section>
    </div>
  );
}
