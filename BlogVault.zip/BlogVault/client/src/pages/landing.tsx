import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Heart, TrendingUp, Cpu, Sparkles, BookOpen, Video, Headphones } from "lucide-react";

export default function Landing() {
  const categories = [
    {
      icon: Heart,
      title: "Health",
      description: "Wellness tips, mental health insights, and fitness guidance for a balanced life.",
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      icon: TrendingUp,
      title: "Finance",
      description: "Investment strategies, budgeting advice, and wealth management insights.",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      icon: Cpu,
      title: "Tech",
      description: "Latest technology trends, software development, and digital transformation.",
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
  ];

  const contentTypes = [
    { icon: BookOpen, label: "Articles", description: "In-depth written content" },
    { icon: Video, label: "Videos", description: "Visual learning experiences" },
    { icon: Headphones, label: "Audio", description: "Listen on the go" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 via-background to-background">
        <div className="absolute inset-0 bg-grid-pattern opacity-5" />
        <div className="container mx-auto max-w-7xl px-6 py-24 md:py-32">
          <div className="flex flex-col items-center text-center space-y-8">
            <Badge variant="secondary" className="px-4 py-2 text-sm font-medium">
              <Sparkles className="h-3.5 w-3.5 mr-2" />
              Expert Insights for Modern Living
            </Badge>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight max-w-4xl leading-tight">
              Insights on{" "}
              <span className="text-green-500">Health</span>,{" "}
              <span className="text-blue-500">Finance</span>, and{" "}
              <span className="text-purple-500">Tech</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
              Discover expert perspectives and actionable insights to help you make better decisions 
              in health, finance, and technology.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/">
                <Button size="lg" className="px-8" data-testid="button-browse-content">
                  Browse Content
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
              <Link href="/about">
                <Button variant="outline" size="lg" className="px-8" data-testid="button-about-author">
                  About the Author
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container mx-auto max-w-7xl px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Explore Topics</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Deep dives into the subjects that matter most for your personal and professional growth.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {categories.map((category) => (
              <Card key={category.title} className="group hover-elevate transition-all duration-200">
                <CardContent className="p-8">
                  <div className={`${category.bgColor} w-14 h-14 rounded-xl flex items-center justify-center mb-6`}>
                    <category.icon className={`h-7 w-7 ${category.color}`} />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">
                    {category.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {category.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Content Types Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto max-w-7xl px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Multiple Formats</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Consume content in the format that works best for you.
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row justify-center gap-6 md:gap-12">
            {contentTypes.map((type) => (
              <div key={type.label} className="flex items-center gap-4 p-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <type.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">{type.label}</h3>
                  <p className="text-sm text-muted-foreground">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container mx-auto max-w-7xl px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Learn?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Start exploring our curated content and gain insights that can transform your life.
          </p>
          <a href="/login">
            <Button 
              size="lg" 
              variant="secondary" 
              className="px-8"
              data-testid="button-get-started"
            >
              Get Started
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </a>
        </div>
      </section>
    </div>
  );
}
