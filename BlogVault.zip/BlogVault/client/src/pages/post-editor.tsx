import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, FileText, Video, Headphones, Save, Eye, Loader2 } from "lucide-react";
import type { Post } from "@shared/schema";

const postFormSchema = z.object({
  title: z.string().min(1, "Title is required").max(255, "Title is too long"),
  content: z.string().min(1, "Content is required"),
  excerpt: z.string().optional(),
  category: z.enum(["health", "finance", "tech"], {
    required_error: "Please select a category",
  }),
  contentType: z.enum(["article", "video", "audio"], {
    required_error: "Please select a content type",
  }),
  mediaUrl: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  thumbnailUrl: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  published: z.boolean().default(true),
});

type PostFormValues = z.infer<typeof postFormSchema>;

export default function PostEditor() {
  const [location, setLocation] = useLocation();
  const postId = location.includes("/admin/post/") && !location.includes("/new") 
    ? location.split("/admin/post/")[1] 
    : null;
  const isEditing = !!postId;
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You need to be logged in to access this page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: existingPost, isLoading: postLoading } = useQuery<Post>({
    queryKey: ["/api/posts", postId],
    enabled: isEditing && isAuthenticated,
  });

  const form = useForm<PostFormValues>({
    resolver: zodResolver(postFormSchema),
    defaultValues: {
      title: "",
      content: "",
      excerpt: "",
      category: "tech",
      contentType: "article",
      mediaUrl: "",
      thumbnailUrl: "",
      published: true,
    },
  });

  useEffect(() => {
    if (existingPost) {
      form.reset({
        title: existingPost.title,
        content: existingPost.content,
        excerpt: existingPost.excerpt || "",
        category: existingPost.category as "health" | "finance" | "tech",
        contentType: existingPost.contentType as "article" | "video" | "audio",
        mediaUrl: existingPost.mediaUrl || "",
        thumbnailUrl: existingPost.thumbnailUrl || "",
        published: existingPost.published ?? true,
      });
    }
  }, [existingPost, form]);

  const createMutation = useMutation({
    mutationFn: async (data: PostFormValues) => {
      const response = await apiRequest("POST", "/api/posts", {
        ...data,
        mediaUrl: data.mediaUrl || null,
        thumbnailUrl: data.thumbnailUrl || null,
        excerpt: data.excerpt || null,
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/posts"] });
      toast({
        title: "Post created",
        description: "Your post has been successfully created.",
      });
      setLocation("/admin");
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create the post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: PostFormValues) => {
      const response = await apiRequest("PATCH", `/api/posts/${postId}`, {
        ...data,
        mediaUrl: data.mediaUrl || null,
        thumbnailUrl: data.thumbnailUrl || null,
        excerpt: data.excerpt || null,
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts", postId] });
      toast({
        title: "Post updated",
        description: "Your post has been successfully updated.",
      });
      setLocation("/admin");
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update the post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PostFormValues) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const contentType = form.watch("contentType");
  const isPending = createMutation.isPending || updateMutation.isPending;

  if (authLoading || (isEditing && postLoading)) {
    return (
      <div className="min-h-screen bg-muted/30 py-8">
        <div className="container mx-auto max-w-4xl px-6">
          <Skeleton className="h-10 w-32 mb-8" />
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-48" />
            </CardHeader>
            <CardContent className="space-y-6">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-12 w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <div className="bg-background border-b sticky top-0 z-40">
        <div className="container mx-auto max-w-4xl px-6 py-4">
          <div className="flex items-center justify-between gap-4">
            <Link href="/admin">
              <Button variant="ghost" className="gap-2" data-testid="button-back-admin">
                <ArrowLeft className="h-4 w-4" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              {isEditing && (
                <Link href={`/post/${postId}`}>
                  <Button variant="outline" size="sm" data-testid="button-preview">
                    <Eye className="h-4 w-4 mr-2" />
                    Preview
                  </Button>
                </Link>
              )}
              <Button
                onClick={form.handleSubmit(onSubmit)}
                disabled={isPending}
                data-testid="button-save-post"
              >
                {isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                {isEditing ? "Update Post" : "Create Post"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-4xl px-6 py-8">
        <Card>
          <CardHeader>
            <CardTitle>{isEditing ? "Edit Post" : "Create New Post"}</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Title */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter post title..."
                          className="text-xl font-semibold"
                          {...field}
                          data-testid="input-title"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Content Type */}
                <FormField
                  control={form.control}
                  name="contentType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Content Type</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          value={field.value}
                          className="flex flex-wrap gap-4"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="article" id="article" data-testid="radio-article" />
                            <label
                              htmlFor="article"
                              className="flex items-center gap-2 text-sm font-medium cursor-pointer"
                            >
                              <FileText className="h-4 w-4" />
                              Article
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="video" id="video" data-testid="radio-video" />
                            <label
                              htmlFor="video"
                              className="flex items-center gap-2 text-sm font-medium cursor-pointer"
                            >
                              <Video className="h-4 w-4" />
                              Video
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="audio" id="audio" data-testid="radio-audio" />
                            <label
                              htmlFor="audio"
                              className="flex items-center gap-2 text-sm font-medium cursor-pointer"
                            >
                              <Headphones className="h-4 w-4" />
                              Audio
                            </label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Category */}
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-category">
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="health">Health</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                          <SelectItem value="tech">Tech</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Media URL (for video/audio) */}
                {(contentType === "video" || contentType === "audio") && (
                  <FormField
                    control={form.control}
                    name="mediaUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          {contentType === "video" ? "Video URL" : "Audio URL"}
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder={
                              contentType === "video"
                                ? "https://www.youtube.com/embed/..."
                                : "https://example.com/audio.mp3"
                            }
                            {...field}
                            data-testid="input-media-url"
                          />
                        </FormControl>
                        <FormDescription>
                          {contentType === "video"
                            ? "Enter an embed URL for the video (YouTube, Vimeo, etc.)"
                            : "Enter a direct link to the audio file"}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {/* Thumbnail URL */}
                <FormField
                  control={form.control}
                  name="thumbnailUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Thumbnail URL (Optional)</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="https://example.com/image.jpg"
                          {...field}
                          data-testid="input-thumbnail"
                        />
                      </FormControl>
                      <FormDescription>
                        Featured image for the post card
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Excerpt */}
                <FormField
                  control={form.control}
                  name="excerpt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Excerpt (Optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Brief summary of the post..."
                          className="resize-none"
                          rows={3}
                          {...field}
                          data-testid="input-excerpt"
                        />
                      </FormControl>
                      <FormDescription>
                        Short description shown on post cards
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Content */}
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Content</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Write your content here..."
                          className="min-h-96 resize-y"
                          {...field}
                          data-testid="input-content"
                        />
                      </FormControl>
                      <FormDescription>
                        Main content of your post. Use line breaks to separate paragraphs.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Published */}
                <FormField
                  control={form.control}
                  name="published"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Publish</FormLabel>
                        <FormDescription>
                          Make this post visible on the main page
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-published"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                {/* Submit Button (Mobile) */}
                <div className="md:hidden">
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isPending}
                    data-testid="button-save-post-mobile"
                  >
                    {isPending ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4 mr-2" />
                    )}
                    {isEditing ? "Update Post" : "Create Post"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
