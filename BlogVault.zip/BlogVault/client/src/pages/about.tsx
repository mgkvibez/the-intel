import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Twitter, Linkedin, Github, Mail, MapPin, Award, BookOpen } from "lucide-react";
import type { AdminProfile, User } from "@shared/schema";

interface AdminData {
  user: User;
  profile: AdminProfile | null;
}

export default function About() {
  const { data: adminData, isLoading } = useQuery<AdminData>({
    queryKey: ["/api/admin/profile"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen py-16">
        <div className="container mx-auto max-w-5xl px-6">
          <div className="flex flex-col md:flex-row gap-12 items-start">
            <Skeleton className="h-48 w-48 rounded-full shrink-0" />
            <div className="flex-1 space-y-4">
              <Skeleton className="h-10 w-64" />
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  const user = adminData?.user;
  const profile = adminData?.profile;
  const fullName = user ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || "Admin" : "Admin";
  
  const socialLinks = (profile?.socialLinks as Record<string, string>) || {};
  const galleryImages = profile?.galleryImages || [];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-primary/5 via-background to-background py-16 md:py-24">
        <div className="container mx-auto max-w-5xl px-6">
          <div className="flex flex-col md:flex-row gap-12 items-center md:items-start">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-3xl scale-75" />
              <Avatar className="h-48 w-48 border-4 border-background shadow-xl relative">
                <AvatarImage 
                  src={user?.profileImageUrl || undefined} 
                  alt={fullName}
                  className="object-cover"
                />
                <AvatarFallback className="text-4xl bg-primary text-primary-foreground">
                  {fullName.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
            </div>
            
            <div className="flex-1 text-center md:text-left space-y-6">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-2">{fullName}</h1>
                <p className="text-xl text-muted-foreground">
                  {profile?.tagline || "Sharing insights on Health, Finance, and Technology"}
                </p>
              </div>
              
              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                <Badge variant="secondary" className="px-3 py-1">
                  <Award className="h-3.5 w-3.5 mr-1.5" />
                  Content Creator
                </Badge>
                <Badge variant="secondary" className="px-3 py-1">
                  <BookOpen className="h-3.5 w-3.5 mr-1.5" />
                  Writer
                </Badge>
              </div>
              
              <div className="flex gap-4 justify-center md:justify-start">
                {socialLinks.twitter && (
                  <a 
                    href={socialLinks.twitter} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="Twitter"
                  >
                    <Twitter className="h-5 w-5" />
                  </a>
                )}
                {socialLinks.linkedin && (
                  <a 
                    href={socialLinks.linkedin} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                )}
                {socialLinks.github && (
                  <a 
                    href={socialLinks.github} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="GitHub"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                )}
                {user?.email && (
                  <a 
                    href={`mailto:${user.email}`}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="Email"
                  >
                    <Mail className="h-5 w-5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bio Section */}
      <section className="py-16">
        <div className="container mx-auto max-w-3xl px-6">
          <Card>
            <CardContent className="p-8">
              <h2 className="text-2xl font-semibold mb-6">About Me</h2>
              <div className="prose prose-lg dark:prose-invert max-w-none">
                {profile?.bio ? (
                  <p className="leading-relaxed text-muted-foreground whitespace-pre-wrap">
                    {profile.bio}
                  </p>
                ) : (
                  <p className="text-muted-foreground">
                    Welcome to my blog! I'm passionate about sharing insights on health, finance, 
                    and technology. Through this platform, I aim to provide valuable content that 
                    helps you make informed decisions in these crucial areas of life.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Gallery Section */}
      {galleryImages && galleryImages.length > 0 && (
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto max-w-6xl px-6">
            <h2 className="text-3xl font-bold mb-8 text-center">Photo Gallery</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {galleryImages.map((image, index) => (
                <div 
                  key={index} 
                  className="relative aspect-square rounded-lg overflow-hidden group"
                >
                  <img
                    src={image}
                    alt={`Gallery image ${index + 1}`}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Stats Section */}
      <section className="py-16">
        <div className="container mx-auto max-w-5xl px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="space-y-2">
              <p className="text-4xl font-bold text-primary">3</p>
              <p className="text-muted-foreground">Topics Covered</p>
            </div>
            <div className="space-y-2">
              <p className="text-4xl font-bold text-primary">Health, Finance, Tech</p>
              <p className="text-muted-foreground">Areas of Expertise</p>
            </div>
            <div className="space-y-2">
              <p className="text-4xl font-bold text-primary">Articles, Videos, Audio</p>
              <p className="text-muted-foreground">Content Formats</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
