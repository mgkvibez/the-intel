import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Calendar, Clock, FileText, Video, Headphones, Share2, Eye } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import type { Post, User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PostWithAuthor extends Post {
  author?: User;
}

const contentTypeIcons = {
  article: FileText,
  video: Video,
  audio: Headphones,
};

const categoryColors: Record<string, string> = {
  health: "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20",
  finance: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
  tech: "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20",
};

export default function PostDetail() {
  const [location] = useLocation();
  const postId = location.split("/post/")[1];
  const { toast } = useToast();
  const [viewTracked, setViewTracked] = useState(false);

  const { data: post, isLoading, error } = useQuery<PostWithAuthor>({
    queryKey: ["/api/posts", postId],
    enabled: !!postId,
  });

  const trackViewMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", `/api/posts/${postId}`, {
        views: (post?.views || 0) + 1,
      });
    },
    onError: (err) => {
      console.error("Error tracking view:", err);
    },
  });

  // Track view after 1 minute of reading
  useEffect(() => {
    if (!post || viewTracked) return;

    const viewTimer = setTimeout(() => {
      setViewTracked(true);
      trackViewMutation.mutate();
    }, 60000); // 1 minute

    return () => clearTimeout(viewTimer);
  }, [post, viewTracked, trackViewMutation]);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: post?.title,
          text: post?.excerpt || post?.content?.substring(0, 100),
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled share
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "The post link has been copied to your clipboard.",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto max-w-3xl px-6">
          <Skeleton className="h-8 w-32 mb-8" />
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-8 w-64 mb-8" />
          <Skeleton className="aspect-video w-full rounded-lg mb-8" />
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto max-w-3xl px-6 text-center py-16">
          <h1 className="text-2xl font-bold mb-4">Post not found</h1>
          <p className="text-muted-foreground mb-8">
            The post you're looking for doesn't exist or has been removed.
          </p>
          <Link href="/">
            <Button data-testid="button-back-home">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const ContentIcon = contentTypeIcons[post.contentType as keyof typeof contentTypeIcons] || FileText;
  const categoryClass = categoryColors[post.category.toLowerCase()] || categoryColors.tech;
  const readTime = Math.ceil((post.content?.length || 0) / 1000);
  const formattedDate = post.createdAt 
    ? format(new Date(post.createdAt), "MMMM d, yyyy")
    : "Recently";
  const relativeDate = post.createdAt 
    ? formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })
    : "Recently";

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <div className="container mx-auto max-w-3xl px-6 py-6">
        <Link href="/">
          <Button variant="ghost" className="gap-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
            Back to Posts
          </Button>
        </Link>
      </div>

      {/* Hero Image */}
      {post.thumbnailUrl && (
        <div className="relative h-64 md:h-96 mb-8">
          <img
            src={post.thumbnailUrl}
            alt={post.title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        </div>
      )}

      {/* Article Content */}
      <article className="container mx-auto max-w-3xl px-6 pb-16">
        {/* Meta Info */}
        <div className="flex flex-wrap items-center gap-3 mb-6">
          <Badge 
            variant="secondary" 
            className="flex items-center gap-1.5 rounded-full"
          >
            <ContentIcon className="h-3 w-3" />
            <span className="capitalize">{post.contentType}</span>
          </Badge>
          <Badge variant="outline" className={`capitalize ${categoryClass}`}>
            {post.category}
          </Badge>
        </div>

        {/* Title */}
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight" data-testid="text-post-title">
          {post.title}
        </h1>

        {/* Author & Date */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-8 mb-8 border-b">
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12">
              <AvatarImage 
                src={post.author?.profileImageUrl || undefined} 
                alt={post.author?.firstName || "Author"}
                className="object-cover"
              />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {post.author?.firstName?.[0] || "A"}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">
                {post.author?.firstName} {post.author?.lastName}
              </p>
              <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
                <span className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  {formattedDate}
                </span>
                {post.contentType === 'article' && (
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {readTime} min read
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <Eye className="h-3.5 w-3.5" />
                  {post.views || 0} views
                </span>
              </div>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleShare} data-testid="button-share">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>

        {/* Video Embed */}
        {post.contentType === 'video' && post.mediaUrl && (
          <div className="aspect-video rounded-lg overflow-hidden mb-8 bg-muted">
            <iframe
              src={post.mediaUrl}
              title={post.title}
              className="h-full w-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        )}

        {/* Audio Player */}
        {post.contentType === 'audio' && post.mediaUrl && (
          <div className="mb-8 p-6 bg-muted rounded-lg">
            <div className="flex items-center gap-4 mb-4">
              <div className="h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center">
                <Headphones className="h-8 w-8 text-primary" />
              </div>
              <div>
                <p className="font-medium">Listen to this episode</p>
                <p className="text-sm text-muted-foreground">Audio content</p>
              </div>
            </div>
            <audio controls className="w-full" src={post.mediaUrl}>
              Your browser does not support the audio element.
            </audio>
          </div>
        )}

        {/* Article Content */}
        <div className="prose prose-lg dark:prose-invert max-w-none" data-testid="text-post-content">
          {post.content?.split('\n').map((paragraph, index) => (
            <p key={index} className="leading-relaxed mb-4">
              {paragraph}
            </p>
          ))}
        </div>
      </article>
    </div>
  );
}
