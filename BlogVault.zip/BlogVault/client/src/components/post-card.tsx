import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, FileText, Video, Headphones, Eye } from "lucide-react";
import type { Post } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface PostCardProps {
  post: Post;
}

const contentTypeIcons = {
  article: FileText,
  video: Video,
  audio: Headphones,
};

const categoryColors: Record<string, string> = {
  health: "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20",
  finance: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
  tech: "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20",
};

export function PostCard({ post }: PostCardProps) {
  const ContentIcon = contentTypeIcons[post.contentType as keyof typeof contentTypeIcons] || FileText;
  const categoryClass = categoryColors[post.category.toLowerCase()] || categoryColors.tech;

  const readTime = Math.ceil((post.content?.length || 0) / 1000);
  const formattedDate = post.createdAt 
    ? formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })
    : "Recently";

  return (
    <Link href={`/post/${post.id}`}>
      <Card 
        className="group overflow-visible h-full flex flex-col hover-elevate cursor-pointer transition-transform duration-200"
        data-testid={`card-post-${post.id}`}
      >
        <div className="relative aspect-video overflow-hidden rounded-t-lg">
          {post.thumbnailUrl ? (
            <img
              src={post.thumbnailUrl}
              alt={post.title}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="h-full w-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
              <ContentIcon className="h-12 w-12 text-muted-foreground/50" />
            </div>
          )}
          <div className="absolute top-3 left-3 flex gap-2">
            <Badge 
              variant="secondary" 
              className="flex items-center gap-1.5 rounded-full px-3 py-1 bg-background/90 backdrop-blur-sm border"
            >
              <ContentIcon className="h-3 w-3" />
              <span className="capitalize">{post.contentType}</span>
            </Badge>
          </div>
        </div>

        <CardContent className="flex-1 p-6">
          <Badge variant="outline" className={`mb-3 capitalize ${categoryClass}`}>
            {post.category}
          </Badge>
          <h3 className="text-xl font-semibold mb-3 line-clamp-2 group-hover:text-primary transition-colors">
            {post.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
            {post.excerpt || post.content?.substring(0, 150)}...
          </p>
        </CardContent>

        <CardFooter className="px-6 pb-6 pt-0">
          <div className="flex items-center justify-between w-full text-sm text-muted-foreground flex-wrap gap-2">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              <span>{formattedDate}</span>
            </div>
            <div className="flex items-center gap-3">
              {post.contentType === 'article' && (
                <div className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5" />
                  <span>{readTime} min read</span>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <Eye className="h-3.5 w-3.5" />
                <span>{post.views || 0} views</span>
              </div>
            </div>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
